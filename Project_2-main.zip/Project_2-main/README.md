Welcome to our site!
Please enter your info, you will be pleased to see that you will find all your needs for future courses.
It will allow you to see comments and reviews from previous students, so you dont waste your time!!

<h1 align="center">CourseCritic</h1>

<p align="center">
    <img src="https://img.shields.io/github/repo-size/doctordutch/Project_2" />
    <img src="https://img.shields.io/github/languages/top/doctordutch/Project_2"  />
    <img src="https://img.shields.io/github/issues/doctordutch/Project_2" />
    <img src="https://img.shields.io/github/last-commit/doctordutch/Project_2" >
</p>

<p align="center">
    <img src="https://img.shields.io/badge/javascript-yellow" />
    <img src="https://img.shields.io/badge/express-orange" />
    <img src="https://img.shields.io/badge/sequelize-blue"  />
    <img src="https://img.shields.io/badge/handlebars-red"  />
    <img src="https://img.shields.io/badge/mySQL-blue"  />
    <img src="https://img.shields.io/badge/dotenv-green" />
</p>