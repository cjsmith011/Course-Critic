INSERT INTO course (id, course_name, school, category, synopsis)
VALUES  ('1', 'Coding Bootcamp', 'Michigan State University', 'Web Design', 'Async classes for front and back end code certification'),
        ('2', 'Game Art & Development', 'SNHU', 'GameDev', 'Online classes in 3D ARt and Design, Creative Design and Character Animation'),
        ('3', 'Data Mining & Analytics', 'Devry University', 'Cyber Security', 'Virtual classes in predictive data models, cloud computing and security'),
        ('4', 'Cyber Security', 'SNHU', 'Cyber Security', 'Foundations, networking, operating system security and cyber defense'),
        ('5', 'Information Technology Essentials', 'DeVry University', 'Web Design', 'Programming, devices and operating system basics'),
        ('6', 'Computer Programming', 'SNHU', 'Web Design', 'Foudational programming & software development'),
        ('7', 'Game Design & Development', 'Michigan State University', 'GameDev', 'Online class, minor degree, game theory and design'),
        ('8', 'Gaming and Interactive Media', 'DeVry University', 'GameDev', 'BS Specialization class for technology majors'),
        ('9', 'CyberSecurity', 'Michigan State University', 'Cyber Security', '24 week bootcamp at College of Engineering');

