const helpers = () => {
    return {
      customHelper: (name) => {
        return `I\'m helping ${name}`
      }/*,
      yourHelper: () => {
  
      }*/
    }
  }
  
  module.exports = helpers